=== omni-workflow ===
Contributors: RalphHanna
Tags: Workflow, Business Processing, BPMN
Requires at least: 4.2
Tested up to: 4.2

Provide a Workflow Engine, Design, Prototyping and Execution of Workflow totally from WordPress


== Description ==
Provide a Workflow Engine, Design, Prototyping and Execution of Workflow totally from WordPress


== Installation ==
Follow normal installation for WordPress Plugins